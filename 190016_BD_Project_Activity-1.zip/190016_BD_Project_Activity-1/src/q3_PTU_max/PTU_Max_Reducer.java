package q3_PTU_max;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class PTU_Max_Reducer extends Reducer<Text, IntWritable, Text, IntWritable>{

	Map<Text, IntWritable> hashMap;
	public void reduce(Text word, Iterable<IntWritable> values, Context con) throws IOException, InterruptedException {
		
		if (hashMap == null) {
			hashMap = new HashMap<Text, IntWritable>();
		}
		
		int sum = 0;
		for (IntWritable value: values) {
			sum = sum+value.get();
		}
		
		hashMap.put(word, new IntWritable(sum));
//		con.write(word, new IntWritable(sum));
	}
	
	public void cleanup(Context con) throws IOException, InterruptedException {
		
		Text highestKey = new Text("");
		IntWritable highestValue = new IntWritable(Integer.MIN_VALUE);
		
		for (Map.Entry<Text, IntWritable> entry : hashMap.entrySet()) {
			if (entry.getValue().get() >= highestValue.get()) {
				highestKey = entry.getKey();
				highestValue = entry.getValue();
			}
		}
		
		String finalKeyString = "Most card use : " + highestKey.toString();
		
		con.write(new Text(finalKeyString), highestValue);
	}
}
